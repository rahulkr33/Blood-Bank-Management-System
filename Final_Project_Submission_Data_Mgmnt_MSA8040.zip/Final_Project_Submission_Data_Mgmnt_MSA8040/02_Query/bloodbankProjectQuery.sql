-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 05, 2023 at 09:20 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bloodbank`
--

-- --------------------------------------------------------

--
-- Table structure for table `bloodavailability`
--

CREATE TABLE `bloodavailability` (
  `BloodAvailabilityID` int(11) NOT NULL,
  `BloodGroup` varchar(5) DEFAULT NULL,
  `UnitsAvailable` int(11) DEFAULT NULL,
  `DonationCenter` varchar(100) DEFAULT NULL,
  `LastUpdated` timestamp NOT NULL DEFAULT current_timestamp(),
  `DonorID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `blooddinfo`
--

CREATE TABLE `blooddinfo` (
  `bdid` int(11) NOT NULL,
  `rid` int(11) NOT NULL,
  `bg` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `blooddinfo`
--

INSERT INTO `blooddinfo` (`bdid`, `rid`, `bg`) VALUES
(10, 1, 'A+'),
(11, 1, 'B-'),
(12, 4, 'B+'),
(13, 4, 'O+'),
(14, 5, 'B+'),
(15, 5, 'B-'),
(16, 5, 'O+'),
(17, 6, 'B+'),
(18, 6, 'AB+'),
(19, 6, 'A-'),
(20, 7, 'AB-'),
(21, 7, 'A-'),
(22, 7, 'O-'),
(23, 1, 'A-'),
(27, 1, 'B+');

-- --------------------------------------------------------

--
-- Table structure for table `blooddonate`
--

CREATE TABLE `blooddonate` (
  `donoid` int(11) NOT NULL,
  `rid` int(11) NOT NULL,
  `hid` int(11) NOT NULL,
  `bg` varchar(11) NOT NULL,
  `status` varchar(100) NOT NULL DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `blooddonate`
--

INSERT INTO `blooddonate` (`donoid`, `rid`, `hid`, `bg`, `status`) VALUES
(6, 4, 1, 'B+', 'Pending'),
(7, 1, 1, 'A+', 'Pending'),
(8, 4, 1, 'B+', 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `blooddonor`
--

CREATE TABLE `blooddonor` (
  `DonorID` int(11) NOT NULL,
  `FirstName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `Gender` varchar(10) DEFAULT NULL,
  `DateOfBirth` date DEFAULT NULL,
  `BloodGroup` varchar(5) DEFAULT NULL,
  `ContactNumber` varchar(15) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `RegistrationDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bloodinfo`
--

CREATE TABLE `bloodinfo` (
  `bid` int(11) NOT NULL,
  `hid` int(11) NOT NULL,
  `bg` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bloodinfo`
--

INSERT INTO `bloodinfo` (`bid`, `hid`, `bg`) VALUES
(7, 1, 'A-'),
(8, 1, 'O+'),
(12, 4, 'A-'),
(13, 4, 'A+'),
(14, 4, 'AB+'),
(16, 5, 'A+'),
(17, 5, 'B-'),
(18, 5, 'O-'),
(20, 5, 'B+'),
(21, 6, 'O+'),
(22, 6, 'A-'),
(23, 6, 'O-'),
(24, 7, 'A-'),
(25, 7, 'A+'),
(26, 7, 'B-'),
(27, 7, 'B+'),
(31, 1, 'B-');

-- --------------------------------------------------------

--
-- Table structure for table `bloodrequest`
--

CREATE TABLE `bloodrequest` (
  `reqid` int(11) NOT NULL,
  `hid` int(11) NOT NULL,
  `rid` int(11) NOT NULL,
  `bg` varchar(11) NOT NULL,
  `status` varchar(100) NOT NULL DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bloodrequest`
--

INSERT INTO `bloodrequest` (`reqid`, `hid`, `rid`, `bg`, `status`) VALUES
(56, 1, 1, 'A-', 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `name` varchar(50) NOT NULL,
  `phoneno` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `donorhealthrecord`
--

CREATE TABLE `donorhealthrecord` (
  `HealthRecordID` int(11) NOT NULL,
  `DonorID` int(11) DEFAULT NULL,
  `BloodPressure` varchar(15) DEFAULT NULL,
  `HemoglobinLevel` decimal(5,2) DEFAULT NULL,
  `CholesterolLevel` decimal(5,2) DEFAULT NULL,
  `MedicalConditions` text DEFAULT NULL,
  `PrescriptionHistory` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hospitals`
--

CREATE TABLE `hospitals` (
  `id` int(11) NOT NULL,
  `hname` varchar(100) NOT NULL,
  `hemail` varchar(100) NOT NULL,
  `hpassword` varchar(100) NOT NULL,
  `hphone` varchar(100) NOT NULL,
  `hcity` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hospitals`
--

INSERT INTO `hospitals` (`id`, `hname`, `hemail`, `hpassword`, `hphone`, `hcity`) VALUES
(1, 'Emory hospital', 'emory@gmail.com', 'emory', '4705996150', 'Atlanta'),
(4, 'Piedmont hospital', 'piedmont@gmail.com', 'piedmont', '4705996151', 'Atlanta'),
(5, 'Northside hospital', 'northside@gmail.com', 'northside', '4705996152', 'Atlanta'),
(6, 'WellStar hospital', 'wellStar@gmail.com', 'wellStar', '4705996153', 'Atlanta'),
(7, 'Grady hospital', 'grady@gmail.com', 'grady', '4705996154', 'Atlanta');

-- --------------------------------------------------------

--
-- Table structure for table `receivers`
--

CREATE TABLE `receivers` (
  `id` int(11) NOT NULL,
  `rname` varchar(100) NOT NULL,
  `remail` varchar(100) NOT NULL,
  `rpassword` varchar(100) NOT NULL,
  `rphone` varchar(100) NOT NULL,
  `rbg` varchar(10) NOT NULL,
  `rcity` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `receivers`
--

INSERT INTO `receivers` (`id`, `rname`, `remail`, `rpassword`, `rphone`, `rbg`, `rcity`) VALUES
(1, 'test', 'test@gmail.com', 'test', '4705996155', 'A+', 'Atlanta'),
(4, 'Rahul', 'rahul@gmail.com', 'rahul', '4705996156', 'B+', 'Atlanta'),
(5, 'Suyog', 'suyog@gmail.com', 'suyog', '4705996157', 'B+', 'Atlanta'),
(6, 'Krishna', 'krishna@gmail.com', 'krishna', '4705996158', 'B+', 'Atlanta'),
(7, 'test1', 'test1@gmail.com', 'test1', '4705996159', 'AB-', 'Atlanta'),
(11, 'test11', 'test11@gmail.com', 'test11', '4705996156', 'A+', 'Atlanta'),
(12, 'test12', 'test12@gmail.com', 'test12', '4705996157', 'B+', 'Boston'),
(13, 'test13', 'test13@gmail.com', 'test13', '4705996158', 'O+', 'Newyork'),
(14, 'test14', 'test14@gmail.com', 'test14', '4705996159', 'A+', 'Miami'),
(15, 'test15', 'test15@gmail.com', 'test15', '4705996160', 'B+', 'Atlanta'),
(16, 'test16', 'test16@gmail.com', 'test16', '4705996161', 'O+', 'Boston'),
(17, 'test17', 'test17@gmail.com', 'test17', '4705996162', 'A+', 'Newyork'),
(18, 'test18', 'test18@gmail.com', 'test18', '4705996163', 'B+', 'Miami'),
(19, 'test19', 'test19@gmail.com', 'test19', '4705996164', 'O+', 'Atlanta'),
(20, 'test20', 'test20@gmail.com', 'test20', '4705996165', 'A+', 'Boston'),
(21, 'test21', 'test21@gmail.com', 'test21', '4705996166', 'B+', 'Newyork'),
(22, 'test22', 'test22@gmail.com', 'test22', '4705996167', 'O+', 'Miami'),
(23, 'test23', 'test23@gmail.com', 'test23', '4705996168', 'A+', 'Atlanta'),
(24, 'test24', 'test24@gmail.com', 'test24', '4705996169', 'B+', 'Boston'),
(25, 'test25', 'test25@gmail.com', 'test25', '4705996170', 'O+', 'Newyork'),
(26, 'test26', 'test26@gmail.com', 'test26', '4705996171', 'A+', 'Miami'),
(27, 'test27', 'test27@gmail.com', 'test27', '4705996172', 'B+', 'Atlanta'),
(28, 'test28', 'test28@gmail.com', 'test28', '4705996173', 'O+', 'Boston'),
(29, 'test29', 'test29@gmail.com', 'test29', '4705996174', 'A+', 'Newyork'),
(30, 'test30', 'test30@gmail.com', 'test30', '4705996175', 'B+', 'Miami'),
(31, 'test31', 'test31@gmail.com', 'test31', '4705996176', 'O+', 'Atlanta'),
(32, 'test32', 'test32@gmail.com', 'test32', '4705996177', 'A+', 'Boston'),
(33, 'test33', 'test33@gmail.com', 'test33', '4705996178', 'B+', 'Newyork'),
(34, 'test34', 'test34@gmail.com', 'test34', '4705996179', 'O+', 'Miami'),
(35, 'test35', 'test35@gmail.com', 'test35', '4705996180', 'A+', 'Atlanta'),
(36, 'test36', 'test36@gmail.com', 'test36', '4705996181', 'B+', 'Boston'),
(37, 'test37', 'test37@gmail.com', 'test37', '4705996182', 'O+', 'Newyork'),
(38, 'test38', 'test38@gmail.com', 'test38', '4705996183', 'A+', 'Miami'),
(39, 'test39', 'test39@gmail.com', 'test39', '4705996184', 'B+', 'Atlanta'),
(40, 'test40', 'test40@gmail.com', 'test40', '4705996185', 'O+', 'Boston'),
(41, 'test41', 'test41@gmail.com', 'test41', '4705996186', 'A+', 'Newyork'),
(42, 'test42', 'test42@gmail.com', 'test42', '4705996187', 'B+', 'Miami'),
(43, 'test43', 'test43@gmail.com', 'test43', '4705996188', 'O+', 'Atlanta'),
(44, 'test44', 'test44@gmail.com', 'test44', '4705996189', 'A+', 'Boston'),
(45, 'test45', 'test45@gmail.com', 'test45', '4705996190', 'B+', 'Newyork'),
(46, 'test46', 'test46@gmail.com', 'test46', '4705996191', 'O+', 'Miami'),
(47, 'test47', 'test47@gmail.com', 'test47', '4705996192', 'A+', 'Atlanta'),
(48, 'test48', 'test48@gmail.com', 'test48', '4705996193', 'B+', 'Boston'),
(49, 'test49', 'test49@gmail.com', 'test49', '4705996194', 'O+', 'Newyork'),
(50, 'test50', 'test50@gmail.com', 'test50', '4705996195', 'A+', 'Miami'),
(51, 'test51', 'test51@gmail.com', 'test51', '4705996196', 'B+', 'Atlanta'),
(52, 'test52', 'test52@gmail.com', 'test52', '4705996197', 'O+', 'Boston'),
(53, 'test53', 'test53@gmail.com', 'test53', '4705996198', 'A+', 'Newyork'),
(54, 'test54', 'test54@gmail.com', 'test54', '4705996199', 'B+', 'Miami'),
(55, 'test55', 'test55@gmail.com', 'test55', '4705996200', 'O+', 'Atlanta'),
(56, 'test56', 'test56@gmail.com', 'test56', '4705996201', 'A+', 'Boston'),
(57, 'test57', 'test57@gmail.com', 'test57', '4705996202', 'B+', 'Newyork'),
(58, 'test58', 'test58@gmail.com', 'test58', '4705996203', 'O+', 'Miami'),
(59, 'test59', 'test59@gmail.com', 'test59', '4705996204', 'A+', 'Atlanta'),
(60, 'test60', 'test60@gmail.com', 'test60', '4705996205', 'B+', 'Boston'),
(61, 'test61', 'test61@gmail.com', 'test61', '4705996206', 'O+', 'Newyork'),
(62, 'test62', 'test62@gmail.com', 'test62', '4705996207', 'A+', 'Miami'),
(63, 'test63', 'test63@gmail.com', 'test63', '4705996208', 'B+', 'Atlanta'),
(64, 'test64', 'test64@gmail.com', 'test64', '4705996209', 'O+', 'Boston'),
(65, 'test65', 'test65@gmail.com', 'test65', '4705996210', 'A+', 'Newyork'),
(66, 'test66', 'test66@gmail.com', 'test66', '4705996211', 'B+', 'Miami'),
(67, 'test67', 'test67@gmail.com', 'test67', '4705996212', 'O+', 'Atlanta'),
(68, 'test68', 'test68@gmail.com', 'test68', '4705996213', 'A+', 'Boston'),
(69, 'test69', 'test69@gmail.com', 'test69', '4705996214', 'B+', 'Newyork'),
(70, 'test70', 'test70@gmail.com', 'test70', '4705996215', 'O+', 'Miami'),
(71, 'test71', 'test71@gmail.com', 'test71', '4705996216', 'A+', 'Atlanta'),
(72, 'test72', 'test72@gmail.com', 'test72', '4705996217', 'B+', 'Boston'),
(73, 'test73', 'test73@gmail.com', 'test73', '4705996218', 'O+', 'Newyork'),
(74, 'test74', 'test74@gmail.com', 'test74', '4705996219', 'A+', 'Miami'),
(75, 'test75', 'test75@gmail.com', 'test75', '4705996220', 'B+', 'Atlanta'),
(76, 'test76', 'test76@gmail.com', 'test76', '4705996221', 'O+', 'Boston'),
(77, 'test77', 'test77@gmail.com', 'test77', '4705996222', 'A+', 'Newyork'),
(78, 'test78', 'test78@gmail.com', 'test78', '4705996223', 'B+', 'Miami'),
(79, 'test79', 'test79@gmail.com', 'test79', '4705996224', 'O+', 'Atlanta'),
(80, 'test80', 'test80@gmail.com', 'test80', '4705996225', 'A+', 'Boston'),
(81, 'test81', 'test81@gmail.com', 'test81', '4705996226', 'B+', 'Newyork'),
(82, 'test82', 'test82@gmail.com', 'test82', '4705996227', 'O+', 'Miami'),
(83, 'test83', 'test83@gmail.com', 'test83', '4705996228', 'A+', 'Atlanta'),
(84, 'test84', 'test84@gmail.com', 'test84', '4705996229', 'B+', 'Boston'),
(85, 'test85', 'test85@gmail.com', 'test85', '4705996230', 'O+', 'Newyork'),
(86, 'test86', 'test86@gmail.com', 'test86', '4705996231', 'A+', 'Miami'),
(87, 'test87', 'test87@gmail.com', 'test87', '4705996232', 'B+', 'Atlanta'),
(88, 'test88', 'test88@gmail.com', 'test88', '4705996233', 'O+', 'Boston'),
(89, 'test89', 'test89@gmail.com', 'test89', '4705996234', 'A+', 'Newyork'),
(90, 'test90', 'test90@gmail.com', 'test90', '4705996235', 'B+', 'Miami'),
(91, 'test91', 'test91@gmail.com', 'test91', '4705996236', 'O+', 'Atlanta'),
(92, 'test92', 'test92@gmail.com', 'test92', '4705996237', 'A+', 'Boston'),
(93, 'test93', 'test93@gmail.com', 'test93', '4705996238', 'B+', 'Newyork'),
(94, 'test94', 'test94@gmail.com', 'test94', '4705996239', 'O+', 'Miami'),
(95, 'test95', 'test95@gmail.com', 'test95', '4705996240', 'A+', 'Atlanta'),
(96, 'test96', 'test96@gmail.com', 'test96', '4705996241', 'B+', 'Boston'),
(97, 'test97', 'test97@gmail.com', 'test97', '4705996242', 'O+', 'Newyork'),
(98, 'test98', 'test98@gmail.com', 'test98', '4705996243', 'A+', 'Miami'),
(99, 'test99', 'test99@gmail.com', 'test99', '4705996244', 'B+', 'Atlanta'),
(100, 'test100', 'test100@gmail.com', 'test100', '4705996245', 'O+', 'Boston'),
(101, 'test101', 'test101@gmail.com', 'test101', '4705996246', 'A+', 'Newyork'),
(102, 'test102', 'test102@gmail.com', 'test102', '4705996247', 'B+', 'Miami'),
(103, 'test103', 'test103@gmail.com', 'test103', '4705996248', 'O+', 'Atlanta'),
(104, 'test104', 'test104@gmail.com', 'test104', '4705996249', 'A+', 'Boston'),
(105, 'test105', 'test105@gmail.com', 'test105', '4705996250', 'B+', 'Newyork'),
(106, 'test106', 'test106@gmail.com', 'test106', '4705996251', 'O+', 'Miami'),
(107, 'test107', 'test107@gmail.com', 'test107', '4705996252', 'A+', 'Atlanta'),
(108, 'test108', 'test108@gmail.com', 'test108', '4705996253', 'B+', 'Boston'),
(109, 'test109', 'test109@gmail.com', 'test109', '4705996254', 'O+', 'Newyork'),
(110, 'test110', 'test110@gmail.com', 'test110', '4705996255', 'A+', 'Miami'),
(111, 'test111', 'test111@gmail.com', 'test111', '4705996256', 'B+', 'Atlanta'),
(112, 'test112', 'test112@gmail.com', 'test112', '4705996257', 'O+', 'Boston'),
(113, 'test113', 'test113@gmail.com', 'test113', '4705996258', 'A+', 'Newyork'),
(114, 'test114', 'test114@gmail.com', 'test114', '4705996259', 'B+', 'Miami'),
(115, 'test115', 'test115@gmail.com', 'test115', '4705996260', 'O+', 'Atlanta');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bloodavailability`
--
ALTER TABLE `bloodavailability`
  ADD PRIMARY KEY (`BloodAvailabilityID`),
  ADD KEY `DonorID` (`DonorID`);

--
-- Indexes for table `blooddinfo`
--
ALTER TABLE `blooddinfo`
  ADD PRIMARY KEY (`bdid`),
  ADD KEY `blooddinfo_ibfk_2` (`rid`);

--
-- Indexes for table `blooddonate`
--
ALTER TABLE `blooddonate`
  ADD PRIMARY KEY (`donoid`),
  ADD KEY `rid` (`rid`);

--
-- Indexes for table `blooddonor`
--
ALTER TABLE `blooddonor`
  ADD PRIMARY KEY (`DonorID`);

--
-- Indexes for table `bloodinfo`
--
ALTER TABLE `bloodinfo`
  ADD PRIMARY KEY (`bid`),
  ADD KEY `hid` (`hid`);

--
-- Indexes for table `bloodrequest`
--
ALTER TABLE `bloodrequest`
  ADD PRIMARY KEY (`reqid`),
  ADD KEY `hid` (`hid`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`name`);

--
-- Indexes for table `donorhealthrecord`
--
ALTER TABLE `donorhealthrecord`
  ADD PRIMARY KEY (`HealthRecordID`),
  ADD KEY `DonorID` (`DonorID`);

--
-- Indexes for table `hospitals`
--
ALTER TABLE `hospitals`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `receivers`
--
ALTER TABLE `receivers`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bloodavailability`
--
ALTER TABLE `bloodavailability`
  MODIFY `BloodAvailabilityID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `blooddinfo`
--
ALTER TABLE `blooddinfo`
  MODIFY `bdid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `blooddonate`
--
ALTER TABLE `blooddonate`
  MODIFY `donoid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `blooddonor`
--
ALTER TABLE `blooddonor`
  MODIFY `DonorID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bloodinfo`
--
ALTER TABLE `bloodinfo`
  MODIFY `bid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `bloodrequest`
--
ALTER TABLE `bloodrequest`
  MODIFY `reqid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT for table `donorhealthrecord`
--
ALTER TABLE `donorhealthrecord`
  MODIFY `HealthRecordID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hospitals`
--
ALTER TABLE `hospitals`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `receivers`
--
ALTER TABLE `receivers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=116;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bloodavailability`
--
ALTER TABLE `bloodavailability`
  ADD CONSTRAINT `bloodavailability_ibfk_1` FOREIGN KEY (`DonorID`) REFERENCES `blooddonor` (`DonorID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `blooddinfo`
--
ALTER TABLE `blooddinfo`
  ADD CONSTRAINT `blooddinfo_ibfk_2` FOREIGN KEY (`rid`) REFERENCES `receivers` (`id`);

--
-- Constraints for table `bloodinfo`
--
ALTER TABLE `bloodinfo`
  ADD CONSTRAINT `bloodinfo_ibfk_1` FOREIGN KEY (`hid`) REFERENCES `hospitals` (`id`);

--
-- Constraints for table `donorhealthrecord`
--
ALTER TABLE `donorhealthrecord`
  ADD CONSTRAINT `donorhealthrecord_ibfk_1` FOREIGN KEY (`DonorID`) REFERENCES `blooddonor` (`DonorID`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
